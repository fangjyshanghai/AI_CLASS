# Caffe_Code_Analysis

本人在阅读Caffe代码时在互联网上的一些资源以及自己和网上一些同学对代码的中文注释，其中注释主要集中在`Solver`、`Net`、`Layer`、`Blob`类的头文件及实现文件。Caffe运行的大概流程可以参考[Caffe Source Code Analysis](http://buptldy.github.io/2016/10/09/2016-10-09-Caffe_Code/)

网上一些对Caffe代码分析的优秀博客：

[http://alanse7en.github.io/posts/](http://alanse7en.github.io/posts/)

[http://yufeigan.github.io/](http://yufeigan.github.io/)

[http://imbinwang.github.io/blog/inside-caffe-code-layer](http://imbinwang.github.io/blog/inside-caffe-code-layer)

[http://blog.csdn.net/seven_first/article/details/47378697](http://blog.csdn.net/seven_first/article/details/47378697)

[http://withwsf.github.io/2016/04/14/Caffe-with-Python-Layer/](http://withwsf.github.io/2016/04/14/Caffe-with-Python-Layer/)
